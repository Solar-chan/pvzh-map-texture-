USE THIS HACK AT YOUR OWN RISK ( BANNED OR KICKED FROM MATCHES )!!!!!

Move card_data_172 To     
Android\data\com.ea.gp.pvzheroes\files\cache\bundles\files\cards

Replace The File If Asked


And recipe_decks_30 To
Android\data\com.ea.gp.pvzheroes\files\cache\bundles\files\deck_recipes

Replace The file If Asked


Open The Game
Go To Zombies Decks And Find "Fast And Furious" Professor Brainstorm Deck

Buy this Deck ( You Will Get 251+4 Valkyrie Cards )

Before Recycle Them, Delete card_data_172 and recipe_decks_30 From

Android\data\com.ea.gp.pvzheroes\files\cache\bundles\files\cards
and
Android\data\com.ea.gp.pvzheroes\files\cache\bundles\files\deck_recipes

Open The Game, Reopen The Game If Crashed ( Make Sure Wi-Fi Is Turned On )

Go And Recycle These Cards And Congratulations, You Have 1.004.000+ Sparks  !! 